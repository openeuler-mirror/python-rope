.. rope documentation master file, created by
   sphinx-quickstart on Sat May 21 18:16:44 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to rope's documentation!
================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   rope 
   library
   configuration
   contributing
   release-process
   dev/issues



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
